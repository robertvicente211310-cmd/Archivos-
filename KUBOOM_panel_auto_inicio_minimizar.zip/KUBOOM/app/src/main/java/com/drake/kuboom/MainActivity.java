package com.drake.kuboom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int OVERLAY_PERMISSION_REQ_CODE = 1234;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Tela criada via código para não dar erro no AIDE
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(Color.parseColor("#0A0014")); // Fundo escuro
        layout.setPadding(50, 50, 50, 50);

        TextView titulo = new TextView(this);
        titulo.setText("DRAKE KUBOOM");
        titulo.setTextColor(Color.parseColor("#FF2E97")); // Rosa Neon
        titulo.setTextSize(28f);
        titulo.setGravity(Gravity.CENTER);
        layout.addView(titulo);

        Button btnIniciar = new Button(this);
        btnIniciar.setText("INICIAR OVERLAY");
        btnIniciar.setTextColor(Color.WHITE);
        btnIniciar.setBackgroundColor(Color.parseColor("#8A2BE2")); // Morado
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 50;
        layout.addView(btnIniciar, lp);

        setContentView(layout);

        btnIniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(MainActivity.this)) {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                    startActivityForResult(intent, OVERLAY_PERMISSION_REQ_CODE);
                } else {
                    iniciarServico();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == OVERLAY_PERMISSION_REQ_CODE) {
            if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
                iniciarServico();
            } else {
                Toast.makeText(this, "Permissão negada!", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void iniciarServico() {
        startService(new Intent(this, FloatingService.class));
        Toast.makeText(this, "Overlay ativado.", Toast.LENGTH_SHORT).show();
        finish();
    }
}