package com.drake.kuboom;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/** Read-only root availability check. Does not change system settings. */
public final class RootAccess {
    private RootAccess() {}
    public static boolean isAvailable() {
        Process p = null;
        try {
            p = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = r.readLine();
            int code = p.waitFor();
            return code == 0 && line != null && line.contains("uid=0");
        } catch (Exception e) {
            return false;
        } finally {
            if (p != null) p.destroy();
        }
    }
}
