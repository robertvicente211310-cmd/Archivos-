package com.drake.kuboom;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingService extends Service {
    private WindowManager wm;
    private LinearLayout panel;
    private TextView bubble;
    private OverlayView overlay;
    private WindowManager.LayoutParams panelParams, overlayParams, bubbleParams;
    private boolean minimized = false;
    private static final String GAME_PACKAGE = "com.Nobodyshot.kuboom";
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private int pink = Color.rgb(255,46,151), cyan = Color.rgb(0,230,255);

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Concede permiso de superposición y vuelve a iniciar.", Toast.LENGTH_LONG).show(); stopSelf(); return;
        }
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        try { createOverlay(); createPanel(); launchGame(); }
        catch (Exception e) { Toast.makeText(this, "No se pudo abrir el panel: " + e.getMessage(), Toast.LENGTH_LONG).show(); stopSelf(); }
    }
    private int windowType() {
        return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
    }
    private void createOverlay() {
        overlay = new OverlayView(this);
        overlayParams = new WindowManager.LayoutParams(-1, -1, windowType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        overlay.setVisibility(View.GONE); wm.addView(overlay, overlayParams);
    }
    private GradientDrawable shape(int color, int strokeColor) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(18)); d.setStroke(dp(1), strokeColor); return d;
    }
    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private void section(LinearLayout root, String title) {
        TextView t = label(title, 11, cyan); t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setPadding(0,dp(12),0,dp(4)); root.addView(t);
    }
    private Switch toggle(LinearLayout root, String title, boolean initial, final Runnable action) {
        Switch s = new Switch(this); s.setText(title); s.setTextColor(Color.WHITE); s.setTextSize(14); s.setPadding(0,dp(7),0,dp(7)); s.setChecked(initial);
        root.addView(s); s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean checked) { action.run(); }
        }); return s;
    }
    private void createPanel() {
        panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(16),dp(14),dp(16),dp(14));
        panel.setBackground(shape(Color.argb(245,10,8,22), pink));
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setOrientation(LinearLayout.HORIZONTAL);
        TextView title = label("VORTEX  /  KUBOOM", 16, pink); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0,-2,1));
        TextView minimize = label("−", 27, Color.WHITE); minimize.setGravity(Gravity.CENTER); minimize.setPadding(dp(10),0,dp(8),0); header.addView(minimize);
        TextView close = label("×", 27, Color.WHITE); close.setGravity(Gravity.CENTER); close.setPadding(dp(8),0,0,0); header.addView(close); panel.addView(header);
        TextView subtitle = label("FLOATING CONTROL PANEL", 9, Color.LTGRAY); subtitle.setPadding(0,dp(3),0,dp(10)); panel.addView(subtitle);
        View divider = new View(this); divider.setBackgroundColor(Color.argb(120,255,46,151)); panel.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
        ScrollView scroll = new ScrollView(this); LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        section(content,"OVERLAY DE PRUEBA");
        toggle(content,"Mostrar overlay",false,new Runnable(){public void run(){}}).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){public void onCheckedChanged(CompoundButton b, boolean checked){overlay.setActive(checked); overlay.setVisibility(checked?View.VISIBLE:View.GONE);}});
        toggle(content,"Línea",true,new Runnable(){public void run(){}}).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){public void onCheckedChanged(CompoundButton b, boolean checked){overlay.setShowLine(checked);}});
        toggle(content,"Box",true,new Runnable(){public void run(){}}).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){public void onCheckedChanged(CompoundButton b, boolean checked){overlay.setShowBox(checked);}});
        toggle(content,"Display / información",true,new Runnable(){public void run(){}}).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){public void onCheckedChanged(CompoundButton b, boolean checked){overlay.setShowInfo(checked);}});
        section(content,"SISTEMA");
        final TextView rootStatus = label("Root: comprobando…",13,Color.WHITE); rootStatus.setPadding(0,dp(6),0,dp(6)); content.addView(rootStatus);
        TextView check = label("⟳  Comprobar root",13,cyan); check.setPadding(0,dp(8),0,dp(8)); content.addView(check);
        check.setOnClickListener(new View.OnClickListener(){public void onClick(View v){ final TextView status = rootStatus; status.setText("Root: comprobando…"); new Thread(new Runnable(){public void run(){ final boolean ok=RootAccess.isAvailable(); status.post(new Runnable(){public void run(){status.setText(ok?"Root: concedido":"Root: no disponible / permiso denegado"); status.setTextColor(ok?cyan:Color.LTGRAY);}});}}).start();}});
        TextView note = label("Las figuras son demostrativas; no leen memoria del juego.",10,Color.LTGRAY); note.setPadding(0,dp(8),0,0); content.addView(note);
        scroll.addView(content); panel.addView(scroll,new LinearLayout.LayoutParams(-1,dp(330)));
        panelParams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,windowType(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP|Gravity.START; panelParams.x=dp(18); panelParams.y=dp(100);
        close.setOnClickListener(new View.OnClickListener(){public void onClick(View v){stopSelf();}});
        minimize.setOnClickListener(new View.OnClickListener(){public void onClick(View v){minimizePanel();}});
        header.setOnTouchListener(new DragListener()); wm.addView(panel,panelParams);
        createBubble();
        new Thread(new Runnable(){public void run(){final boolean ok=RootAccess.isAvailable(); rootStatus.post(new Runnable(){public void run(){rootStatus.setText(ok?"Root: concedido":"Root: no disponible / permiso denegado"); rootStatus.setTextColor(ok?cyan:Color.LTGRAY);}});}}).start();
    }

    private void launchGame() {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(GAME_PACKAGE);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                startActivity(launch);
            } else {
                Toast.makeText(this, "No encuentro Kuboom instalado (" + GAME_PACKAGE + ").", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir el juego: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void createBubble() {
        bubble = label("V", 17, Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        bubble.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bubble.setBackground(shape(Color.rgb(138,43,226), cyan));
        bubble.setElevation(dp(8));
        bubble.setVisibility(View.GONE);
        bubbleParams = new WindowManager.LayoutParams(dp(52), dp(52), windowType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(12); bubbleParams.y = dp(150);
        bubble.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ restorePanel(); }});
        bubble.setOnTouchListener(new BubbleDragListener());
        wm.addView(bubble, bubbleParams);
    }

    private void minimizePanel() {
        if (panel == null || bubble == null) return;
        minimized = true;
        panel.setVisibility(View.GONE);
        bubble.setVisibility(View.VISIBLE);
    }

    private void restorePanel() {
        if (panel == null || bubble == null) return;
        minimized = false;
        bubble.setVisibility(View.GONE);
        panel.setVisibility(View.VISIBLE);
        try { wm.updateViewLayout(panel, panelParams); } catch (Exception ignored) {}
    }

    private class BubbleDragListener implements View.OnTouchListener {
        int x, y; float tx, ty; boolean moved;
        public boolean onTouch(View v, MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) { x=bubbleParams.x; y=bubbleParams.y; tx=e.getRawX(); ty=e.getRawY(); moved=false; return true; }
            if (e.getAction() == MotionEvent.ACTION_MOVE) {
                int dx=(int)(e.getRawX()-tx), dy=(int)(e.getRawY()-ty);
                if (Math.abs(dx)>dp(4) || Math.abs(dy)>dp(4)) moved=true;
                bubbleParams.x=x+dx; bubbleParams.y=y+dy;
                try { wm.updateViewLayout(bubble,bubbleParams); } catch(Exception ignored) {}
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_UP) { if (!moved) restorePanel(); return true; }
            return true;
        }
    }

    private class DragListener implements View.OnTouchListener {
        int x,y; float tx,ty;
        public boolean onTouch(View v, MotionEvent e) {
            if(e.getAction()==MotionEvent.ACTION_DOWN){x=panelParams.x;y=panelParams.y;tx=e.getRawX();ty=e.getRawY();return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE){panelParams.x=x+(int)(e.getRawX()-tx);panelParams.y=y+(int)(e.getRawY()-ty);try{wm.updateViewLayout(panel,panelParams);}catch(Exception ignored){}return true;}
            return false;
        }
    }
    @Override public void onDestroy(){super.onDestroy(); if(wm!=null){try{if(panel!=null)wm.removeView(panel);}catch(Exception ignored){}try{if(bubble!=null)wm.removeView(bubble);}catch(Exception ignored){}try{if(overlay!=null)wm.removeView(overlay);}catch(Exception ignored){}}}
}
