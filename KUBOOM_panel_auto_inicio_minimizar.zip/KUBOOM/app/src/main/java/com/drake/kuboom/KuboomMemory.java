package com.drake.kuboom;

public class KuboomMemory {
    
    // ==========================================
    // AQUI É ONDE VOCÊ COLOCA OS OFFSETS DO DUMP
    // Quando você tiver os números reais, troque os 0x0
    // ==========================================
    public static final long PLAYER_OFFSET_X = 0x0; 
    public static final long PLAYER_OFFSET_Y = 0x0; 
    public static final long BALL_OFFSET_X = 0x0; 
    public static final long BALL_OFFSET_Y = 0x0; 

    // ==========================================
    // SIMULAÇÃO PARA TESTAR A LINHA NA TELA
    // ==========================================
    public static float[] getPlayerPosition() {
        // Simula a bola branca no centro da tela
        return new float[]{500, 800}; 
    }

    public static float[] getBallPosition() {
        // Simula a bola alvo em outro lugar
        return new float[]{700, 400}; 
    }
}