package com.drake.kuboom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Visual demo overlay. Coordinates are illustrative, not read from the game. */
public class OverlayView extends View {
    private final Paint line = new Paint(3);
    private final Paint box = new Paint(3);
    private final Paint text = new Paint(3);
    private boolean active, showLine = true, showBox = true, showInfo = true;

    public OverlayView(Context context) {
        super(context);
        line.setColor(Color.rgb(0, 230, 255)); line.setStrokeWidth(3f); line.setStyle(Paint.Style.STROKE);
        box.setColor(Color.rgb(255, 46, 151)); box.setStrokeWidth(3f); box.setStyle(Paint.Style.STROKE);
        text.setColor(Color.WHITE); text.setTextSize(13f); text.setShadowLayer(5, 0, 1, Color.BLACK);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }
    public void setActive(boolean value) { active = value; invalidate(); }
    public void setShowLine(boolean value) { showLine = value; invalidate(); }
    public void setShowBox(boolean value) { showBox = value; invalidate(); }
    public void setShowInfo(boolean value) { showInfo = value; invalidate(); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (!active) return;
        float w = getWidth(), h = getHeight();
        // Demo marker only: no game-memory access and no player tracking.
        float cx = w * .68f, cy = h * .42f;
        RectF r = new RectF(cx - 45, cy - 75, cx + 45, cy + 75);
        if (showLine) c.drawLine(w * .5f, h * .82f, cx, r.bottom, line);
        if (showBox) c.drawRoundRect(r, 8, 8, box);
        c.drawCircle(cx, cy - 75, 4, box);
        if (showInfo) {
            c.drawText("OVERLAY DEMO", r.left, r.top - 14, text);
            c.drawText("No live game data", r.left, r.bottom + 20, text);
        }
    }
}
